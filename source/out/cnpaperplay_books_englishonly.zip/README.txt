For your first experience simply print out these two books:
cnduet_1-10_p1.pdf
cnduet_1-10_p2.pdf

These two 10 page books are all you need to play.
Give one to each player, along with a pen or pencil, and go!

The first page of each book has all the instructions you need.